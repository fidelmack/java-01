package com.sankhya.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SankhyaConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
