package com.sankhya.produto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SankhyaProdutoApplicationTests {

	@Test
	void contextLoads() {
	}

}
