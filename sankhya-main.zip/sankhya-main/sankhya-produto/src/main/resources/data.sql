INSERT INTO tb_produto (nm_nome, valor) values ('Arroz', 4.6);
INSERT INTO tb_produto (nm_nome, valor) values ('Feijao', 6.48);
INSERT INTO tb_produto (nm_nome, valor) values ('Farinha', 2.80);