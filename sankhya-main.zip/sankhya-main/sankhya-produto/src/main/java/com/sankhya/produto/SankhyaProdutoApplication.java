package com.sankhya.produto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SankhyaProdutoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SankhyaProdutoApplication.class, args);
	}

}
