package interfac;

@FunctionalInterface
public interface Autentica  {

	public abstract boolean autentica(String senha);
	
}
